-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

DROP TABLE Items;

DROP TABLE Receipts;

DROP TABLE Goods;

DROP TABLE Customers;