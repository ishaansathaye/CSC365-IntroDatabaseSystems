-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

SELECT * FROM Airlines;
SELECT COUNT(*) FROM Airlines;

SELECT * FROM Airports;
SELECT COUNT(*) FROM Airports;

SELECT * FROM Flights;
SELECT COUNT(*) FROM Flights;
