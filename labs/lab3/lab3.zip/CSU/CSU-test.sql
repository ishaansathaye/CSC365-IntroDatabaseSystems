-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

SELECT * FROM Campuses;
SELECT COUNT(*) FROM Campuses;

SELECT * FROM Fees;
SELECT COUNT(*) FROM Fees;

SELECT * FROM Degrees;
SELECT COUNT(*) FROM Degrees;

SELECT * FROM Disciplines;
SELECT COUNT(*) FROM Disciplines;

SELECT * FROM DiscEnrollments;
SELECT COUNT(*) FROM DiscEnrollments;

SELECT * FROM Enrollments;
SELECT COUNT(*) FROM Enrollments;

SELECT * FROM Faculty;
SELECT COUNT(*) FROM Faculty;
