-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

SELECT * FROM Appellations;
SELECT COUNT(*) FROM Appellations;

SELECT * FROM Grapes;
SELECT COUNT(*) FROM Grapes;

SELECT * FROM Wine;
SELECT COUNT(*) FROM Wine;
