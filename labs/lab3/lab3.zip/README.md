# **Name:** Ishaan Sathaye

# **Cal Poly Email:** isathaye@calpoly.edu

# **Notes:** No errors encountered when running scripts.