-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

INSERT INTO Models
	VALUES (1,1,'amc');
INSERT INTO Models
	VALUES (2,2,'audi');
INSERT INTO Models
	VALUES (3,3,'bmw');
INSERT INTO Models
	VALUES (4,4,'buick');
INSERT INTO Models
	VALUES (5,4,'cadillac');
INSERT INTO Models
	VALUES (6,5,'capri');
INSERT INTO Models
	VALUES (7,4,'chevrolet');
INSERT INTO Models
	VALUES (8,6,'chrysler');
INSERT INTO Models
	VALUES (9,7,'citroen');
INSERT INTO Models
	VALUES (10,8,'datsun');
INSERT INTO Models
	VALUES (11,6,'dodge');
INSERT INTO Models
	VALUES (12,9,'fiat');
INSERT INTO Models
	VALUES (13,5,'ford');
INSERT INTO Models
	VALUES (14,10,'hi');
INSERT INTO Models
	VALUES (15,11,'honda');
INSERT INTO Models
	VALUES (16,12,'mazda');
INSERT INTO Models
	VALUES (17,13,'mercedes');
INSERT INTO Models
	VALUES (18,13,'mercedes-benz');
INSERT INTO Models
	VALUES (19,5,'mercury');
INSERT INTO Models
	VALUES (20,8,'nissan');
INSERT INTO Models
	VALUES (21,4,'oldsmobile');
INSERT INTO Models
	VALUES (22,14,'opel');
INSERT INTO Models
	VALUES (23,15,'peugeot');
INSERT INTO Models
	VALUES (24,6,'plymouth');
INSERT INTO Models
	VALUES (25,4,'pontiac');
INSERT INTO Models
	VALUES (26,16,'renault');
INSERT INTO Models
	VALUES (27,17,'saab');
INSERT INTO Models
	VALUES (28,18,'subaru');
INSERT INTO Models
	VALUES (29,19,'toyota');
INSERT INTO Models
	VALUES (30,20,'triumph');
INSERT INTO Models
	VALUES (31,2,'volkswagen');
INSERT INTO Models
	VALUES (32,21,'volvo');
INSERT INTO Models
	VALUES (33,22,'kia');
INSERT INTO Models
	VALUES (34,23,'hyundai');
INSERT INTO Models
	VALUES (35,6,'jeep');
INSERT INTO Models
	VALUES (36,19,'scion');
