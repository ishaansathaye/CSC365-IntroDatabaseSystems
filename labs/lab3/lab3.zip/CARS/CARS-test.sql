-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

SELECT * FROM Continents;
SELECT COUNT(*) FROM Continents;

SELECT * FROM Countries;
SELECT COUNT(*) FROM Countries;

SELECT * FROM CarMakers;
SELECT COUNT(*) FROM CarMakers;

SELECT * FROM Models;
SELECT COUNT(*) FROM Models;

SELECT * FROM Makes;
SELECT COUNT(*) FROM Makes;

SELECT * FROM CarsData;
SELECT COUNT(*) FROM CarsData;
