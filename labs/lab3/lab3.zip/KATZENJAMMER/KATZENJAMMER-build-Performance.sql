-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

INSERT INTO Performance
	VALUES (1,1,'back');
INSERT INTO Performance
	VALUES (1,2,'left');
INSERT INTO Performance
	VALUES (1,3,'center');
INSERT INTO Performance
	VALUES (1,4,'right');
INSERT INTO Performance
	VALUES (2,1,'center');
INSERT INTO Performance
	VALUES (2,2,'back');
INSERT INTO Performance
	VALUES (2,3,'left');
INSERT INTO Performance
	VALUES (2,4,'right');
INSERT INTO Performance
	VALUES (3,1,'back');
INSERT INTO Performance
	VALUES (3,2,'right');
INSERT INTO Performance
	VALUES (3,3,'center');
INSERT INTO Performance
	VALUES (3,4,'left');
INSERT INTO Performance
	VALUES (4,1,'back');
INSERT INTO Performance
	VALUES (4,2,'center');
INSERT INTO Performance
	VALUES (4,3,'left');
INSERT INTO Performance
	VALUES (4,4,'right');
INSERT INTO Performance
	VALUES (5,1,'back');
INSERT INTO Performance
	VALUES (5,2,'left');
INSERT INTO Performance
	VALUES (5,3,'center');
INSERT INTO Performance
	VALUES (5,4,'right');
INSERT INTO Performance
	VALUES (6,1,'center');
INSERT INTO Performance
	VALUES (6,2,'center');
INSERT INTO Performance
	VALUES (6,3,'left');
INSERT INTO Performance
	VALUES (6,4,'right');
INSERT INTO Performance
	VALUES (7,1,'back');
INSERT INTO Performance
	VALUES (7,2,'left');
INSERT INTO Performance
	VALUES (7,3,'center');
INSERT INTO Performance
	VALUES (7,4,'right');
INSERT INTO Performance
	VALUES (8,1,'back');
INSERT INTO Performance
	VALUES (8,2,'left');
INSERT INTO Performance
	VALUES (8,3,'center');
INSERT INTO Performance
	VALUES (8,4,'right');
INSERT INTO Performance
	VALUES (9,1,'center');
INSERT INTO Performance
	VALUES (9,2,'left');
INSERT INTO Performance
	VALUES (9,3,'right');
INSERT INTO Performance
	VALUES (9,4,'left');
INSERT INTO Performance
	VALUES (10,1,'center');
INSERT INTO Performance
	VALUES (10,2,'center');
INSERT INTO Performance
	VALUES (10,3,'center');
INSERT INTO Performance
	VALUES (10,4,'center');
INSERT INTO Performance
	VALUES (11,1,'right');
INSERT INTO Performance
	VALUES (11,2,'left');
INSERT INTO Performance
	VALUES (11,3,'center');
INSERT INTO Performance
	VALUES (11,4,'back');
INSERT INTO Performance
	VALUES (12,1,'right');
INSERT INTO Performance
	VALUES (12,2,'center');
INSERT INTO Performance
	VALUES (12,3,'left');
INSERT INTO Performance
	VALUES (12,4,'center');
INSERT INTO Performance
	VALUES (13,1,'back');
INSERT INTO Performance
	VALUES (13,2,'center');
INSERT INTO Performance
	VALUES (13,3,'left');
INSERT INTO Performance
	VALUES (13,4,'right');
INSERT INTO Performance
	VALUES (14,1,'back');
INSERT INTO Performance
	VALUES (14,2,'left');
INSERT INTO Performance
	VALUES (14,3,'left');
INSERT INTO Performance
	VALUES (14,4,'center');
INSERT INTO Performance
	VALUES (15,1,'center');
INSERT INTO Performance
	VALUES (15,2,'right');
INSERT INTO Performance
	VALUES (15,3,'left');
INSERT INTO Performance
	VALUES (15,4,'back');
INSERT INTO Performance
	VALUES (16,1,'center');
INSERT INTO Performance
	VALUES (16,2,'center');
INSERT INTO Performance
	VALUES (16,3,'left');
INSERT INTO Performance
	VALUES (16,4,'right');
INSERT INTO Performance
	VALUES (17,1,'back');
INSERT INTO Performance
	VALUES (17,2,'center');
INSERT INTO Performance
	VALUES (17,3,'left');
INSERT INTO Performance
	VALUES (17,4,'right');
INSERT INTO Performance
	VALUES (18,1,'left');
INSERT INTO Performance
	VALUES (18,2,'right');
INSERT INTO Performance
	VALUES (18,3,'left');
INSERT INTO Performance
	VALUES (18,4,'center');
INSERT INTO Performance
	VALUES (19,1,'center');
INSERT INTO Performance
	VALUES (19,2,'right');
INSERT INTO Performance
	VALUES (19,3,'left');
INSERT INTO Performance
	VALUES (19,4,'back');
INSERT INTO Performance
	VALUES (20,1,'left');
INSERT INTO Performance
	VALUES (20,2,'back');
INSERT INTO Performance
	VALUES (20,3,'center');
INSERT INTO Performance
	VALUES (20,4,'right');
INSERT INTO Performance
	VALUES (21,1,'left');
INSERT INTO Performance
	VALUES (21,2,'left');
INSERT INTO Performance
	VALUES (21,3,'left');
INSERT INTO Performance
	VALUES (21,4,'center');
INSERT INTO Performance
	VALUES (22,1,'left');
INSERT INTO Performance
	VALUES (22,2,'back');
INSERT INTO Performance
	VALUES (22,3,'center');
INSERT INTO Performance
	VALUES (22,4,'right');
INSERT INTO Performance
	VALUES (23,1,'center');
INSERT INTO Performance
	VALUES (23,2,'center');
INSERT INTO Performance
	VALUES (23,3,'center');
INSERT INTO Performance
	VALUES (23,4,'center');
INSERT INTO Performance
	VALUES (24,1,'back');
INSERT INTO Performance
	VALUES (24,2,'center');
INSERT INTO Performance
	VALUES (24,3,'left');
INSERT INTO Performance
	VALUES (24,4,'right');
INSERT INTO Performance
	VALUES (25,1,'back');
INSERT INTO Performance
	VALUES (25,2,'center');
INSERT INTO Performance
	VALUES (25,3,'left');
INSERT INTO Performance
	VALUES (25,4,'right');
INSERT INTO Performance
	VALUES (26,1,'back');
INSERT INTO Performance
	VALUES (26,2,'center');
INSERT INTO Performance
	VALUES (26,3,'left');
INSERT INTO Performance
	VALUES (26,4,'right');
INSERT INTO Performance
	VALUES (27,1,'back');
INSERT INTO Performance
	VALUES (27,2,'center');
INSERT INTO Performance
	VALUES (27,3,'left');
INSERT INTO Performance
	VALUES (27,4,'right');
INSERT INTO Performance
	VALUES (28,1,'back');
INSERT INTO Performance
	VALUES (28,2,'right');
INSERT INTO Performance
	VALUES (28,3,'left');
INSERT INTO Performance
	VALUES (28,4,'center');
INSERT INTO Performance
	VALUES (29,1,'back');
INSERT INTO Performance
	VALUES (29,2,'left');
INSERT INTO Performance
	VALUES (29,3,'center');
INSERT INTO Performance
	VALUES (29,4,'right');
INSERT INTO Performance
	VALUES (30,1,'back');
INSERT INTO Performance
	VALUES (30,2,'left');
INSERT INTO Performance
	VALUES (30,3,'center');
INSERT INTO Performance
	VALUES (30,4,'right');
INSERT INTO Performance
	VALUES (31,1,'back');
INSERT INTO Performance
	VALUES (31,2,'center');
INSERT INTO Performance
	VALUES (31,3,'left');
INSERT INTO Performance
	VALUES (31,4,'right');
INSERT INTO Performance
	VALUES (32,1,'center');
INSERT INTO Performance
	VALUES (32,2,'left');
INSERT INTO Performance
	VALUES (32,3,'back');
INSERT INTO Performance
	VALUES (32,4,'right');
INSERT INTO Performance
	VALUES (33,1,'center');
INSERT INTO Performance
	VALUES (33,2,'left');
INSERT INTO Performance
	VALUES (33,3,'center');
INSERT INTO Performance
	VALUES (33,4,'right');
INSERT INTO Performance
	VALUES (34,1,'center');
INSERT INTO Performance
	VALUES (34,2,'back');
INSERT INTO Performance
	VALUES (34,3,'left');
INSERT INTO Performance
	VALUES (34,4,'right');
INSERT INTO Performance
	VALUES (35,1,'center');
INSERT INTO Performance
	VALUES (35,2,'center');
INSERT INTO Performance
	VALUES (35,3,'left');
INSERT INTO Performance
	VALUES (35,4,'right');
INSERT INTO Performance
	VALUES (36,1,'center');
INSERT INTO Performance
	VALUES (36,2,'back');
INSERT INTO Performance
	VALUES (36,3,'left');
INSERT INTO Performance
	VALUES (36,4,'right');
INSERT INTO Performance
	VALUES (37,1,'back');
INSERT INTO Performance
	VALUES (37,2,'left');
INSERT INTO Performance
	VALUES (37,3,'center');
INSERT INTO Performance
	VALUES (37,4,'right');
INSERT INTO Performance
	VALUES (38,1,'back');
INSERT INTO Performance
	VALUES (38,2,'right');
INSERT INTO Performance
	VALUES (38,3,'left');
INSERT INTO Performance
	VALUES (38,4,'center');
INSERT INTO Performance
	VALUES (39,1,'left');
INSERT INTO Performance
	VALUES (39,2,'right');
INSERT INTO Performance
	VALUES (39,3,'center');
INSERT INTO Performance
	VALUES (39,4,'back');
INSERT INTO Performance
	VALUES (40,1,'center');
INSERT INTO Performance
	VALUES (40,2,'right');
INSERT INTO Performance
	VALUES (40,3,'center');
INSERT INTO Performance
	VALUES (40,4,'left');
INSERT INTO Performance
	VALUES (41,1,'back');
INSERT INTO Performance
	VALUES (41,2,'center');
INSERT INTO Performance
	VALUES (41,3,'left');
INSERT INTO Performance
	VALUES (41,4,'right');
INSERT INTO Performance
	VALUES (42,1,'center');
INSERT INTO Performance
	VALUES (42,2,'right');
INSERT INTO Performance
	VALUES (42,3,'left');
INSERT INTO Performance
	VALUES (42,4,'back');
INSERT INTO Performance
	VALUES (43,1,'center');
INSERT INTO Performance
	VALUES (43,2,'center');
INSERT INTO Performance
	VALUES (43,3,'left');
INSERT INTO Performance
	VALUES (43,4,'right');
