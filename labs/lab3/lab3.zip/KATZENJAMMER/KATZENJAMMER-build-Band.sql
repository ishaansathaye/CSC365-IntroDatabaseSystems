-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

INSERT INTO Band
	VALUES (1,'Solveig','Heilo');
INSERT INTO Band
	VALUES (2,'Marianne','Sveen');
INSERT INTO Band
	VALUES (3,'Anne-Marit','Bergheim');
INSERT INTO Band
	VALUES (4,'Turid','Jorgensen');
