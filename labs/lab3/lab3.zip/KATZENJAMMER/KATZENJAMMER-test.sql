-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

SELECT * FROM Albums;
SELECT COUNT(*) FROM Albums;

SELECT * FROM Band;
SELECT COUNT(*) FROM Band;

SELECT * FROM Songs;
SELECT COUNT(*) FROM Songs;

SELECT * FROM Instruments;
SELECT COUNT(*) FROM Instruments;

SELECT * FROM Performance;
SELECT COUNT(*) FROM Performance;

SELECT * FROM Tracklists;
SELECT COUNT(*) FROM Tracklists;

SELECT * FROM Vocals;
SELECT COUNT(*) FROM Vocals;
