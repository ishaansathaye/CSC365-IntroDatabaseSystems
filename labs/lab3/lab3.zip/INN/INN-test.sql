-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

SELECT * FROM Rooms;
SELECT COUNT(*) FROM Rooms;

SELECT * FROM Reservations;
SELECT COUNT(*) FROM Reservations;
