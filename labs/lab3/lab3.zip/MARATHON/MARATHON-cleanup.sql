-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

DROP TABLE Marathon;
