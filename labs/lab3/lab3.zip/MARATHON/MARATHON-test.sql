-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

SELECT * FROM Marathon;
SELECT COUNT(*) FROM Marathon;
