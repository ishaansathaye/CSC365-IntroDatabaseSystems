-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

DROP TABLE Wine;

DROP TABLE Grapes;

DROP TABLE Appellations;
