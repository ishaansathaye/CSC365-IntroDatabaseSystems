-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

INSERT INTO Instruments
	VALUES (1,1,'trumpet');
INSERT INTO Instruments
	VALUES (1,2,'keyboard');
INSERT INTO Instruments
	VALUES (1,3,'accordion');
INSERT INTO Instruments
	VALUES (1,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (2,1,'trumpet');
INSERT INTO Instruments
	VALUES (2,2,'drums');
INSERT INTO Instruments
	VALUES (2,3,'guitar');
INSERT INTO Instruments
	VALUES (2,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (3,1,'drums');
INSERT INTO Instruments
	VALUES (3,1,'ukalele');
INSERT INTO Instruments
	VALUES (3,2,'banjo');
INSERT INTO Instruments
	VALUES (3,3,'bass balalaika');
INSERT INTO Instruments
	VALUES (3,4,'keyboards');
INSERT INTO Instruments
	VALUES (4,1,'drums');
INSERT INTO Instruments
	VALUES (4,2,'ukalele');
INSERT INTO Instruments
	VALUES (4,3,'accordion');
INSERT INTO Instruments
	VALUES (4,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (5,1,'drums');
INSERT INTO Instruments
	VALUES (5,2,'keyboards');
INSERT INTO Instruments
	VALUES (5,3,'guitar');
INSERT INTO Instruments
	VALUES (5,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (6,1,'xylophone');
INSERT INTO Instruments
	VALUES (6,2,'guitar');
INSERT INTO Instruments
	VALUES (6,3,'keyboards');
INSERT INTO Instruments
	VALUES (6,4,'mandolin');
INSERT INTO Instruments
	VALUES (7,1,'drums');
INSERT INTO Instruments
	VALUES (7,2,'keyboards');
INSERT INTO Instruments
	VALUES (7,3,'guitar');
INSERT INTO Instruments
	VALUES (7,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (8,1,'trumpet');
INSERT INTO Instruments
	VALUES (8,1,'drums');
INSERT INTO Instruments
	VALUES (8,2,'keyboards');
INSERT INTO Instruments
	VALUES (8,3,'accordion');
INSERT INTO Instruments
	VALUES (8,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (9,1,'xylophone');
INSERT INTO Instruments
	VALUES (9,2,'keyboards');
INSERT INTO Instruments
	VALUES (9,3,'bass balalaika');
INSERT INTO Instruments
	VALUES (9,4,'accordion');
INSERT INTO Instruments
	VALUES (10,1,'guitar');
INSERT INTO Instruments
	VALUES (10,1,'harmonica');
INSERT INTO Instruments
	VALUES (10,2,'bass balalaika');
INSERT INTO Instruments
	VALUES (10,3,'mandolin');
INSERT INTO Instruments
	VALUES (10,4,'banjo');
INSERT INTO Instruments
	VALUES (11,1,'bass balalaika');
INSERT INTO Instruments
	VALUES (11,2,'keyboards');
INSERT INTO Instruments
	VALUES (11,3,'accordion');
INSERT INTO Instruments
	VALUES (11,4,'drums');
INSERT INTO Instruments
	VALUES (12,1,'bass balalaika');
INSERT INTO Instruments
	VALUES (12,2,'accordion');
INSERT INTO Instruments
	VALUES (12,3,'keyboards');
INSERT INTO Instruments
	VALUES (12,4,'mandolin');
INSERT INTO Instruments
	VALUES (13,1,'drums');
INSERT INTO Instruments
	VALUES (13,2,'guitar');
INSERT INTO Instruments
	VALUES (13,2,'plastic kazoo');
INSERT INTO Instruments
	VALUES (13,3,'mandolin');
INSERT INTO Instruments
	VALUES (13,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (14,1,'drums');
INSERT INTO Instruments
	VALUES (14,2,'keyboards');
INSERT INTO Instruments
	VALUES (14,3,'keyboards');
INSERT INTO Instruments
	VALUES (14,4,'accordion');
INSERT INTO Instruments
	VALUES (15,1,'guitar');
INSERT INTO Instruments
	VALUES (15,2,'bass balalaika');
INSERT INTO Instruments
	VALUES (15,3,'xylophone');
INSERT INTO Instruments
	VALUES (15,3,'accordion');
INSERT INTO Instruments
	VALUES (15,3,'harmonica');
INSERT INTO Instruments
	VALUES (15,4,'mandolin');
INSERT INTO Instruments
	VALUES (15,4,'drums');
INSERT INTO Instruments
	VALUES (16,1,'washboard');
INSERT INTO Instruments
	VALUES (16,2,'ukalele');
INSERT INTO Instruments
	VALUES (16,3,'banjo');
INSERT INTO Instruments
	VALUES (16,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (17,1,'drums');
INSERT INTO Instruments
	VALUES (17,2,'guitar');
INSERT INTO Instruments
	VALUES (17,3,'keyboards');
INSERT INTO Instruments
	VALUES (17,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (18,1,'keyboards');
INSERT INTO Instruments
	VALUES (18,2,'banjo');
INSERT INTO Instruments
	VALUES (18,3,'keyboards');
INSERT INTO Instruments
	VALUES (18,4,'xylophone');
INSERT INTO Instruments
	VALUES (19,1,'banjo');
INSERT INTO Instruments
	VALUES (19,2,'bass balalaika');
INSERT INTO Instruments
	VALUES (19,3,'mandolin');
INSERT INTO Instruments
	VALUES (19,4,'drums');
INSERT INTO Instruments
	VALUES (19,4,'accordion');
INSERT INTO Instruments
	VALUES (20,1,'keyboards');
INSERT INTO Instruments
	VALUES (20,2,'drums');
INSERT INTO Instruments
	VALUES (20,3,'guitar');
INSERT INTO Instruments
	VALUES (20,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (21,1,'trumpet');
INSERT INTO Instruments
	VALUES (21,1,'keyboards');
INSERT INTO Instruments
	VALUES (21,2,'keyboards');
INSERT INTO Instruments
	VALUES (21,3,'banjo');
INSERT INTO Instruments
	VALUES (21,4,'xylophone');
INSERT INTO Instruments
	VALUES (21,4,'mandoline');
INSERT INTO Instruments
	VALUES (22,1,'guitar');
INSERT INTO Instruments
	VALUES (22,2,'drums');
INSERT INTO Instruments
	VALUES (22,3,'banjo');
INSERT INTO Instruments
	VALUES (22,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (23,1,'domra');
INSERT INTO Instruments
	VALUES (23,2,'ukalele');
INSERT INTO Instruments
	VALUES (23,3,'mandolin');
INSERT INTO Instruments
	VALUES (23,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (24,1,'drums');
INSERT INTO Instruments
	VALUES (24,2,'guitar');
INSERT INTO Instruments
	VALUES (24,3,'keyboards');
INSERT INTO Instruments
	VALUES (24,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (25,1,'drums');
INSERT INTO Instruments
	VALUES (26,1,'drums');
INSERT INTO Instruments
	VALUES (26,2,'guitar');
INSERT INTO Instruments
	VALUES (26,3,'banjo');
INSERT INTO Instruments
	VALUES (26,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (27,1,'drums');
INSERT INTO Instruments
	VALUES (27,2,'guitar');
INSERT INTO Instruments
	VALUES (27,3,'banjo');
INSERT INTO Instruments
	VALUES (27,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (28,1,'drums');
INSERT INTO Instruments
	VALUES (28,2,'bass balalaika');
INSERT INTO Instruments
	VALUES (28,3,'guitar');
INSERT INTO Instruments
	VALUES (28,4,'mandolin');
INSERT INTO Instruments
	VALUES (29,1,'drums');
INSERT INTO Instruments
	VALUES (29,2,'keyboards');
INSERT INTO Instruments
	VALUES (29,3,'guitar');
INSERT INTO Instruments
	VALUES (29,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (30,1,'drums');
INSERT INTO Instruments
	VALUES (30,2,'keyboards');
INSERT INTO Instruments
	VALUES (30,3,'guitar');
INSERT INTO Instruments
	VALUES (30,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (31,1,'drums');
INSERT INTO Instruments
	VALUES (31,2,'guitar');
INSERT INTO Instruments
	VALUES (31,2,'toy piano');
INSERT INTO Instruments
	VALUES (31,3,'ukalele');
INSERT INTO Instruments
	VALUES (31,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (32,1,'guitar');
INSERT INTO Instruments
	VALUES (32,2,'banjo');
INSERT INTO Instruments
	VALUES (32,3,'drums');
INSERT INTO Instruments
	VALUES (32,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (33,1,'ukalele');
INSERT INTO Instruments
	VALUES (33,2,'guitar');
INSERT INTO Instruments
	VALUES (33,3,'banjo');
INSERT INTO Instruments
	VALUES (33,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (34,1,'ukalele');
INSERT INTO Instruments
	VALUES (34,2,'drums');
INSERT INTO Instruments
	VALUES (34,3,'accordion');
INSERT INTO Instruments
	VALUES (34,4,'bass');
INSERT INTO Instruments
	VALUES (35,1,'ukalele');
INSERT INTO Instruments
	VALUES (35,2,'guitar');
INSERT INTO Instruments
	VALUES (35,3,'mandolin');
INSERT INTO Instruments
	VALUES (35,4,'bass');
INSERT INTO Instruments
	VALUES (36,1,'toy piano');
INSERT INTO Instruments
	VALUES (36,1,'ukalele');
INSERT INTO Instruments
	VALUES (36,2,'drums');
INSERT INTO Instruments
	VALUES (36,3,'guitar');
INSERT INTO Instruments
	VALUES (36,4,'bass');
INSERT INTO Instruments
	VALUES (37,1,'drums');
INSERT INTO Instruments
	VALUES (37,2,'keyboards');
INSERT INTO Instruments
	VALUES (37,3,'guitar');
INSERT INTO Instruments
	VALUES (37,4,'bass');
INSERT INTO Instruments
	VALUES (38,1,'drums');
INSERT INTO Instruments
	VALUES (38,2,'bass');
INSERT INTO Instruments
	VALUES (38,3,'guitar');
INSERT INTO Instruments
	VALUES (38,4,'guitar');
INSERT INTO Instruments
	VALUES (39,1,'ukalele');
INSERT INTO Instruments
	VALUES (39,2,'bass');
INSERT INTO Instruments
	VALUES (39,3,'dobro');
INSERT INTO Instruments
	VALUES (39,4,'drums');
INSERT INTO Instruments
	VALUES (39,4,'banjo');
INSERT INTO Instruments
	VALUES (40,1,'guitar');
INSERT INTO Instruments
	VALUES (40,2,'bass');
INSERT INTO Instruments
	VALUES (40,3,'small guitar');
INSERT INTO Instruments
	VALUES (40,4,'accordion');
INSERT INTO Instruments
	VALUES (41,1,'drums');
INSERT INTO Instruments
	VALUES (41,2,'guitar');
INSERT INTO Instruments
	VALUES (41,3,'banjo');
INSERT INTO Instruments
	VALUES (41,4,'bass balalaika');
INSERT INTO Instruments
	VALUES (43,1,'washboard');
INSERT INTO Instruments
	VALUES (43,2,'ukalele');
INSERT INTO Instruments
	VALUES (43,2,'kazoo');
INSERT INTO Instruments
	VALUES (43,3,'banjo');
INSERT INTO Instruments
	VALUES (43,4,'bass balalaika');
