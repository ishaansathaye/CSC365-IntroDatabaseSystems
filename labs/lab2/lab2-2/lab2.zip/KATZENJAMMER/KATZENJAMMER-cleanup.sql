-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

DROP TABLE Vocals;

DROP TABLE Tracklists;

DROP TABLE Performance;

DROP TABLE Instruments;

DROP TABLE Songs;

DROP TABLE Band;

DROP TABLE Albums;
