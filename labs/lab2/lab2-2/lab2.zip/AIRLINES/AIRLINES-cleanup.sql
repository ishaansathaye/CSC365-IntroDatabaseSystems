-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

DROP TABLE Flights;

DROP TABLE Airports;

DROP TABLE Airlines;
