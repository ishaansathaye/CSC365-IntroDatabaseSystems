-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

DROP TABLE CarsData;

DROP TABLE Makes;

DROP TABLE Models;

DROP TABLE CarMakers;

DROP TABLE Countries;

DROP TABLE Continents;