-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

INSERT INTO Disciplines
	VALUES (1,'Agriculture');
INSERT INTO Disciplines
	VALUES (2,'Architecture');
INSERT INTO Disciplines
	VALUES (3,'Area Studies');
INSERT INTO Disciplines
	VALUES (4,'Biological Sciences');
INSERT INTO Disciplines
	VALUES (5,'Business and Management');
INSERT INTO Disciplines
	VALUES (6,'Communications');
INSERT INTO Disciplines
	VALUES (7,'Computer and Info. Sciences');
INSERT INTO Disciplines
	VALUES (8,'Education');
INSERT INTO Disciplines
	VALUES (9,'Engineering');
INSERT INTO Disciplines
	VALUES (10,'Fine and Applied Arts');
INSERT INTO Disciplines
	VALUES (11,'Foreign Languages');
INSERT INTO Disciplines
	VALUES (12,'Health Professions');
INSERT INTO Disciplines
	VALUES (13,'Home Economics');
INSERT INTO Disciplines
	VALUES (14,'Interdisciplinary Studies');
INSERT INTO Disciplines
	VALUES (15,'Letters');
INSERT INTO Disciplines
	VALUES (16,'Library');
INSERT INTO Disciplines
	VALUES (17,'Mathematics');
INSERT INTO Disciplines
	VALUES (18,'Physical Sciences');
INSERT INTO Disciplines
	VALUES (19,'Psychology');
INSERT INTO Disciplines
	VALUES (20,'Public Affairs');
INSERT INTO Disciplines
	VALUES (21,'Social Sciences');
INSERT INTO Disciplines
	VALUES (22,'Undeclared');
