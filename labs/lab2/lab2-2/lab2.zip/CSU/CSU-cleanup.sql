-- Name: Ishaan Sathaye
-- Cal Poly Email: isathaye@calpoly.edu

DROP TABLE Faculty;

DROP TABLE Enrollments;

DROP TABLE DiscEnrollments;

DROP TABLE Disciplines;

DROP TABLE Degrees;

DROP TABLE Fees;

DROP TABLE Campuses;
