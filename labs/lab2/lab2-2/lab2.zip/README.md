# **Name:** Ishaan Sathaye

# **Cal Poly Email:** isathaye@calpoly.edu

# **Notes:** All scripts ran successfully with no errors.